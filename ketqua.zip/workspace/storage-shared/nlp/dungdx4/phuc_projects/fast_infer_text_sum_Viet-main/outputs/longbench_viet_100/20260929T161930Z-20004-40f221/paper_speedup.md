# Paired speedup results (contract v2)

Common reference: `vanilla_fa`. Output mismatches remain timing pairs and are reported as quality signals.

## Pairwise results

| Dataset | Baseline | Common ESR (95% CI) | Decode time ratio | Decode rate ratio | Output rate ratio | n ESR | n decode | Native ESR | Native decode rate | Common exact text | Native exact text | Mean token ratio | Mean output tokens | Degenerate rate | p50/p90 request ms | ROUGE-1 F | ROUGE-L F |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| vietnews | vanilla_fa | 1.0 [1.0, 1.0] | 1.0 | 1.0 | 1.0 | 1 | 1 | — | — | 1.0 | — | 1.0 | 8.0 | 0.0 | 356.7489106208086/356.7489106208086 | 0.0541 | 0.0541 |
| vietnews | vanilla_hf | 1.07569826 [1.07569826, 1.07569826] | 1.89442353 | 1.89442353 | 1.07569826 | 1 | 1 | — | — | 1.0 | — | 1.0 | 8.0 | 0.0 | 331.6440340131521/331.6440340131521 | 0.0541 | 0.0541 |
| vietnews | eagle3 | 0.78189788 [0.78189788, 0.78189788] | 0.4945555 | 0.56520629 | 0.78189788 | 1 | 1 | 0.5249474 | 0.30174302 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 456.2602359801531/456.2602359801531 | 0.0541 | 0.0541 |
| vietnews | dflash | 2.31791191 [2.31791191, 2.31791191] | 2.3920621 | 2.3920621 | 2.31791191 | 1 | 1 | 2.84243143 | 3.22563002 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 153.90960685908794/153.90960685908794 | 0.0541 | 0.0541 |
| vietnews | domino | 11.27453734 [11.27453734, 11.27453734] | 140981.17518859 | 140981.17518859 | 11.27453734 | 1 | 1 | 1.07164528 | 0.79108392 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 31.642/31.642 | 0.0541 | 0.0541 |
| vietnews | dspark | 10.40569684 [10.40569684, 10.40569684] | 208779.88921132 | 208779.88921132 | 10.40569684 | 1 | 1 | 0.98906195 | 1.17152104 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 34.284/34.284 | 0.0541 | 0.0541 |
| wikilingua | vanilla_fa | 1.0 [1.0, 1.0] | 1.0 | 1.0 | 1.0 | 1 | 1 | — | — | 1.0 | — | 1.0 | 8.0 | 0.0 | 276.1418540030718/276.1418540030718 | 0.1667 | 0.1667 |
| wikilingua | vanilla_hf | 0.93739192 [0.93739192, 0.93739192] | 1.47733865 | 1.47733865 | 0.93739192 | 1 | 1 | — | — | 1.0 | — | 1.0 | 8.0 | 0.0 | 294.5852717384696/294.5852717384696 | 0.1667 | 0.1667 |
| wikilingua | eagle3 | 0.36302694 [0.36302694, 0.36302694] | 0.22307125 | 0.25493857 | 0.36302694 | 1 | 1 | 0.29076866 | 0.20197669 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 760.6649100780487/760.6649100780487 | 0.1667 | 0.1667 |
| wikilingua | dflash | 3.11877162 [3.11877162, 3.11877162] | 3.14890434 | 3.14890434 | 3.11877162 | 1 | 1 | 3.52847477 | 4.15187052 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 88.54186441749334/88.54186441749334 | 0.1667 | 0.1667 |
| wikilingua | domino | 11.67865739 [11.67865739, 11.67865739] | 128634.98199515 | 128634.98199515 | 11.67865739 | 1 | 1 | 1.3242546 | 0.98729983 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 23.645/23.645 | 0.1667 | 0.1667 |
| wikilingua | dspark | 11.86839103 [11.86839103, 11.86839103] | 129926.35381663 | 129926.35381663 | 11.86839103 | 1 | 1 | 1.34576869 | 0.99721138 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 23.267/23.267 | 0.1667 | 0.1667 |
| vims | vanilla_fa | 1.0 [1.0, 1.0] | 1.0 | 1.0 | 1.0 | 1 | 1 | — | — | 1.0 | — | 1.0 | 8.0 | 0.0 | 235.41731387376785/235.41731387376785 | 0.1449 | 0.087 |
| vims | vanilla_hf | 0.53697395 [0.53697395, 0.53697395] | 1.02261988 | 1.02261988 | 0.53697395 | 1 | 1 | — | — | 0.0 | — | 1.0 | 8.0 | 0.0 | 438.41477297246456/438.41477297246456 | 0.1739 | 0.1159 |
| vims | eagle3 | 0.51707506 [0.51707506, 0.51707506] | 0.26698902 | 0.30513031 | 0.51707506 | 1 | 1 | 0.5746246 | 0.29359588 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 455.2865419536829/455.2865419536829 | 0.1449 | 0.087 |
| vims | dflash | 1.36774958 [1.36774958, 1.36774958] | 1.28198077 | 1.28198077 | 1.36774958 | 1 | 1 | 2.93451225 | 3.23283994 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 172.12018743157387/172.12018743157387 | 0.1449 | 0.087 |
| vims | domino | 5.59159455 [5.59159455, 5.59159455] | 101528.00793944 | 101528.00793944 | 5.59159455 | 1 | 1 | 0.94266306 | 0.82471562 | 0.0 | 1.0 | 1.0 | 8.0 | 0.0 | 42.102/42.102 | 0.1739 | 0.1159 |
| vims | dspark | 5.80117084 [5.80117084, 5.80117084] | 111819.57138661 | 111819.57138661 | 5.80117084 | 1 | 1 | 0.97799463 | 0.90831435 | 1.0 | 0.0 | 1.0 | 8.0 | 0.0 | 40.581/40.581 | 0.1449 | 0.087 |
| vlsp | vanilla_fa | 1.0 [1.0, 1.0] | 1.0 | 1.0 | 1.0 | 1 | 1 | — | — | 1.0 | — | 1.0 | 8.0 | 0.0 | 265.2569357305765/265.2569357305765 | 0.0157 | 0.0157 |
| vlsp | vanilla_hf | 1.07741075 [1.07741075, 1.07741075] | 1.27175753 | 1.27175753 | 1.07741075 | 1 | 1 | — | — | 1.0 | — | 1.0 | 8.0 | 0.0 | 246.19852285832167/246.19852285832167 | 0.0157 | 0.0157 |
| vlsp | eagle3 | 0.69614477 [0.69614477, 0.69614477] | 0.3186725 | 0.36419714 | 0.69614477 | 1 | 1 | 0.61953774 | 0.33541508 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 381.0370275750756/381.0370275750756 | 0.0157 | 0.0157 |
| vlsp | dflash | 2.7308528 [2.7308528, 2.7308528] | 2.57395526 | 2.57395526 | 2.7308528 | 1 | 1 | 4.21770456 | 5.01007332 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 97.13337011635303/97.13337011635303 | 0.0157 | 0.0157 |
| vlsp | domino | 8.05860177 [8.05860177, 8.05860177] | 116199.16795966 | 116199.16795966 | 8.05860177 | 1 | 1 | 0.99586827 | 0.99493528 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 32.916/32.916 | 0.0157 | 0.0157 |
| vlsp | dspark | 9.12664932 [9.12664932, 9.12664932] | 137199.94781682 | 137199.94781682 | 9.12664932 | 1 | 1 | 1.12785577 | 1.17475083 | 1.0 | 1.0 | 1.0 | 8.0 | 0.0 | 29.064/29.064 | 0.0157 | 0.0157 |

## Six-way shared-set and four-dataset geometric mean

The shared-set table uses identical successful sample IDs across all six baselines for each metric. Geometric means weight each dataset equally; bootstrap CIs are stratified by dataset.

| Scope | Dataset | Baseline | Metric | Ratio | 95% paired CI | n |
|---|---|---|---|---:|---:|---:|
| six_way_shared | vietnews | vanilla_fa | common_esr | 1.0 | [1.0, 1.0] | 1 |
| six_way_shared | vietnews | vanilla_hf | common_esr | 1.07569826 | [1.07569826, 1.07569826] | 1 |
| six_way_shared | vietnews | eagle3 | common_esr | 0.78189788 | [0.78189788, 0.78189788] | 1 |
| six_way_shared | vietnews | dflash | common_esr | 2.31791191 | [2.31791191, 2.31791191] | 1 |
| six_way_shared | vietnews | domino | common_esr | 11.27453734 | [11.27453734, 11.27453734] | 1 |
| six_way_shared | vietnews | dspark | common_esr | 10.40569684 | [10.40569684, 10.40569684] | 1 |
| six_way_shared | vietnews | vanilla_fa | common_decode_time_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | vietnews | vanilla_hf | common_decode_time_ratio | 1.89442353 | [1.89442353, 1.89442353] | 0 |
| six_way_shared | vietnews | eagle3 | common_decode_time_ratio | 0.4945555 | [0.4945555, 0.4945555] | 0 |
| six_way_shared | vietnews | dflash | common_decode_time_ratio | 2.3920621 | [2.3920621, 2.3920621] | 0 |
| six_way_shared | vietnews | domino | common_decode_time_ratio | 140981.17518859 | [140981.17518859, 140981.17518859] | 0 |
| six_way_shared | vietnews | dspark | common_decode_time_ratio | 208779.88921132 | [208779.88921132, 208779.88921132] | 0 |
| six_way_shared | vietnews | vanilla_fa | common_decode_rate_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | vietnews | vanilla_hf | common_decode_rate_ratio | 1.89442353 | [1.89442353, 1.89442353] | 0 |
| six_way_shared | vietnews | eagle3 | common_decode_rate_ratio | 0.56520629 | [0.56520629, 0.56520629] | 0 |
| six_way_shared | vietnews | dflash | common_decode_rate_ratio | 2.3920621 | [2.3920621, 2.3920621] | 0 |
| six_way_shared | vietnews | domino | common_decode_rate_ratio | 140981.17518859 | [140981.17518859, 140981.17518859] | 0 |
| six_way_shared | vietnews | dspark | common_decode_rate_ratio | 208779.88921132 | [208779.88921132, 208779.88921132] | 0 |
| six_way_shared | vietnews | vanilla_fa | common_output_rate_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | vietnews | vanilla_hf | common_output_rate_ratio | 1.07569826 | [1.07569826, 1.07569826] | 0 |
| six_way_shared | vietnews | eagle3 | common_output_rate_ratio | 0.78189788 | [0.78189788, 0.78189788] | 0 |
| six_way_shared | vietnews | dflash | common_output_rate_ratio | 2.31791191 | [2.31791191, 2.31791191] | 0 |
| six_way_shared | vietnews | domino | common_output_rate_ratio | 11.27453734 | [11.27453734, 11.27453734] | 0 |
| six_way_shared | vietnews | dspark | common_output_rate_ratio | 10.40569684 | [10.40569684, 10.40569684] | 0 |
| six_way_shared | wikilingua | vanilla_fa | common_esr | 1.0 | [1.0, 1.0] | 1 |
| six_way_shared | wikilingua | vanilla_hf | common_esr | 0.93739192 | [0.93739192, 0.93739192] | 1 |
| six_way_shared | wikilingua | eagle3 | common_esr | 0.36302694 | [0.36302694, 0.36302694] | 1 |
| six_way_shared | wikilingua | dflash | common_esr | 3.11877162 | [3.11877162, 3.11877162] | 1 |
| six_way_shared | wikilingua | domino | common_esr | 11.67865739 | [11.67865739, 11.67865739] | 1 |
| six_way_shared | wikilingua | dspark | common_esr | 11.86839103 | [11.86839103, 11.86839103] | 1 |
| six_way_shared | wikilingua | vanilla_fa | common_decode_time_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | wikilingua | vanilla_hf | common_decode_time_ratio | 1.47733865 | [1.47733865, 1.47733865] | 0 |
| six_way_shared | wikilingua | eagle3 | common_decode_time_ratio | 0.22307125 | [0.22307125, 0.22307125] | 0 |
| six_way_shared | wikilingua | dflash | common_decode_time_ratio | 3.14890434 | [3.14890434, 3.14890434] | 0 |
| six_way_shared | wikilingua | domino | common_decode_time_ratio | 128634.98199515 | [128634.98199515, 128634.98199515] | 0 |
| six_way_shared | wikilingua | dspark | common_decode_time_ratio | 129926.35381663 | [129926.35381663, 129926.35381663] | 0 |
| six_way_shared | wikilingua | vanilla_fa | common_decode_rate_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | wikilingua | vanilla_hf | common_decode_rate_ratio | 1.47733865 | [1.47733865, 1.47733865] | 0 |
| six_way_shared | wikilingua | eagle3 | common_decode_rate_ratio | 0.25493857 | [0.25493857, 0.25493857] | 0 |
| six_way_shared | wikilingua | dflash | common_decode_rate_ratio | 3.14890434 | [3.14890434, 3.14890434] | 0 |
| six_way_shared | wikilingua | domino | common_decode_rate_ratio | 128634.98199515 | [128634.98199515, 128634.98199515] | 0 |
| six_way_shared | wikilingua | dspark | common_decode_rate_ratio | 129926.35381663 | [129926.35381663, 129926.35381663] | 0 |
| six_way_shared | wikilingua | vanilla_fa | common_output_rate_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | wikilingua | vanilla_hf | common_output_rate_ratio | 0.93739192 | [0.93739192, 0.93739192] | 0 |
| six_way_shared | wikilingua | eagle3 | common_output_rate_ratio | 0.36302694 | [0.36302694, 0.36302694] | 0 |
| six_way_shared | wikilingua | dflash | common_output_rate_ratio | 3.11877162 | [3.11877162, 3.11877162] | 0 |
| six_way_shared | wikilingua | domino | common_output_rate_ratio | 11.67865739 | [11.67865739, 11.67865739] | 0 |
| six_way_shared | wikilingua | dspark | common_output_rate_ratio | 11.86839103 | [11.86839103, 11.86839103] | 0 |
| six_way_shared | vims | vanilla_fa | common_esr | 1.0 | [1.0, 1.0] | 1 |
| six_way_shared | vims | vanilla_hf | common_esr | 0.53697395 | [0.53697395, 0.53697395] | 1 |
| six_way_shared | vims | eagle3 | common_esr | 0.51707506 | [0.51707506, 0.51707506] | 1 |
| six_way_shared | vims | dflash | common_esr | 1.36774958 | [1.36774958, 1.36774958] | 1 |
| six_way_shared | vims | domino | common_esr | 5.59159455 | [5.59159455, 5.59159455] | 1 |
| six_way_shared | vims | dspark | common_esr | 5.80117084 | [5.80117084, 5.80117084] | 1 |
| six_way_shared | vims | vanilla_fa | common_decode_time_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | vims | vanilla_hf | common_decode_time_ratio | 1.02261988 | [1.02261988, 1.02261988] | 0 |
| six_way_shared | vims | eagle3 | common_decode_time_ratio | 0.26698902 | [0.26698902, 0.26698902] | 0 |
| six_way_shared | vims | dflash | common_decode_time_ratio | 1.28198077 | [1.28198077, 1.28198077] | 0 |
| six_way_shared | vims | domino | common_decode_time_ratio | 101528.00793944 | [101528.00793944, 101528.00793944] | 0 |
| six_way_shared | vims | dspark | common_decode_time_ratio | 111819.57138661 | [111819.57138661, 111819.57138661] | 0 |
| six_way_shared | vims | vanilla_fa | common_decode_rate_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | vims | vanilla_hf | common_decode_rate_ratio | 1.02261988 | [1.02261988, 1.02261988] | 0 |
| six_way_shared | vims | eagle3 | common_decode_rate_ratio | 0.30513031 | [0.30513031, 0.30513031] | 0 |
| six_way_shared | vims | dflash | common_decode_rate_ratio | 1.28198077 | [1.28198077, 1.28198077] | 0 |
| six_way_shared | vims | domino | common_decode_rate_ratio | 101528.00793944 | [101528.00793944, 101528.00793944] | 0 |
| six_way_shared | vims | dspark | common_decode_rate_ratio | 111819.57138661 | [111819.57138661, 111819.57138661] | 0 |
| six_way_shared | vims | vanilla_fa | common_output_rate_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | vims | vanilla_hf | common_output_rate_ratio | 0.53697395 | [0.53697395, 0.53697395] | 0 |
| six_way_shared | vims | eagle3 | common_output_rate_ratio | 0.51707506 | [0.51707506, 0.51707506] | 0 |
| six_way_shared | vims | dflash | common_output_rate_ratio | 1.36774958 | [1.36774958, 1.36774958] | 0 |
| six_way_shared | vims | domino | common_output_rate_ratio | 5.59159455 | [5.59159455, 5.59159455] | 0 |
| six_way_shared | vims | dspark | common_output_rate_ratio | 5.80117084 | [5.80117084, 5.80117084] | 0 |
| six_way_shared | vlsp | vanilla_fa | common_esr | 1.0 | [1.0, 1.0] | 1 |
| six_way_shared | vlsp | vanilla_hf | common_esr | 1.07741075 | [1.07741075, 1.07741075] | 1 |
| six_way_shared | vlsp | eagle3 | common_esr | 0.69614477 | [0.69614477, 0.69614477] | 1 |
| six_way_shared | vlsp | dflash | common_esr | 2.7308528 | [2.7308528, 2.7308528] | 1 |
| six_way_shared | vlsp | domino | common_esr | 8.05860177 | [8.05860177, 8.05860177] | 1 |
| six_way_shared | vlsp | dspark | common_esr | 9.12664932 | [9.12664932, 9.12664932] | 1 |
| six_way_shared | vlsp | vanilla_fa | common_decode_time_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | vlsp | vanilla_hf | common_decode_time_ratio | 1.27175753 | [1.27175753, 1.27175753] | 0 |
| six_way_shared | vlsp | eagle3 | common_decode_time_ratio | 0.3186725 | [0.3186725, 0.3186725] | 0 |
| six_way_shared | vlsp | dflash | common_decode_time_ratio | 2.57395526 | [2.57395526, 2.57395526] | 0 |
| six_way_shared | vlsp | domino | common_decode_time_ratio | 116199.16795966 | [116199.16795966, 116199.16795966] | 0 |
| six_way_shared | vlsp | dspark | common_decode_time_ratio | 137199.94781682 | [137199.94781682, 137199.94781682] | 0 |
| six_way_shared | vlsp | vanilla_fa | common_decode_rate_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | vlsp | vanilla_hf | common_decode_rate_ratio | 1.27175753 | [1.27175753, 1.27175753] | 0 |
| six_way_shared | vlsp | eagle3 | common_decode_rate_ratio | 0.36419714 | [0.36419714, 0.36419714] | 0 |
| six_way_shared | vlsp | dflash | common_decode_rate_ratio | 2.57395526 | [2.57395526, 2.57395526] | 0 |
| six_way_shared | vlsp | domino | common_decode_rate_ratio | 116199.16795966 | [116199.16795966, 116199.16795966] | 0 |
| six_way_shared | vlsp | dspark | common_decode_rate_ratio | 137199.94781682 | [137199.94781682, 137199.94781682] | 0 |
| six_way_shared | vlsp | vanilla_fa | common_output_rate_ratio | 1.0 | [1.0, 1.0] | 0 |
| six_way_shared | vlsp | vanilla_hf | common_output_rate_ratio | 1.07741075 | [1.07741075, 1.07741075] | 0 |
| six_way_shared | vlsp | eagle3 | common_output_rate_ratio | 0.69614477 | [0.69614477, 0.69614477] | 0 |
| six_way_shared | vlsp | dflash | common_output_rate_ratio | 2.7308528 | [2.7308528, 2.7308528] | 0 |
| six_way_shared | vlsp | domino | common_output_rate_ratio | 8.05860177 | [8.05860177, 8.05860177] | 0 |
| six_way_shared | vlsp | dspark | common_output_rate_ratio | 9.12664932 | [9.12664932, 9.12664932] | 0 |
| four_dataset_geomean | ALL | vanilla_fa | common_esr | 1.0 | [1.0, 1.0] | 4 |
| four_dataset_geomean | ALL | vanilla_hf | common_esr | 0.8739499254614684 | [0.8739499254614684, 0.8739499254614684] | 4 |
| four_dataset_geomean | ALL | eagle3 | common_esr | 0.5653735811810107 | [0.5653735811810107, 0.5653735811810107] | 4 |
| four_dataset_geomean | ALL | dflash | common_esr | 2.279535423009335 | [2.279535423009335, 2.279535423009335] | 4 |
| four_dataset_geomean | ALL | domino | common_esr | 8.776508015607593 | [8.776508015607593, 8.776508015607593] | 4 |
| four_dataset_geomean | ALL | dspark | common_esr | 8.992335639975163 | [8.992335639975163, 8.992335639975163] | 4 |
| four_dataset_geomean | ALL | vanilla_fa | common_decode_time_ratio | 1.0 | [1.0, 1.0] | 4 |
| four_dataset_geomean | ALL | vanilla_hf | common_decode_time_ratio | 1.3812392865543297 | [1.3812392865543297, 1.3812392865543297] | 4 |
| four_dataset_geomean | ALL | eagle3 | common_decode_time_ratio | 0.31126060434861375 | [0.31126060434861375, 0.31126060434861375] | 4 |
| four_dataset_geomean | ALL | dflash | common_decode_time_ratio | 2.2328194441007145 | [2.2328194441007145, 2.2328194441007145] | 4 |
| four_dataset_geomean | ALL | domino | common_decode_time_ratio | 120942.03586108041 | [120942.03586108041, 120942.03586108041] | 4 |
| four_dataset_geomean | ALL | dspark | common_decode_time_ratio | 142828.35054202395 | [142828.35054202395, 142828.35054202395] | 4 |
| four_dataset_geomean | ALL | vanilla_fa | common_decode_rate_ratio | 1.0 | [1.0, 1.0] | 4 |
| four_dataset_geomean | ALL | vanilla_hf | common_decode_rate_ratio | 1.3812392865543295 | [1.3812392865543295, 1.3812392865543295] | 4 |
| four_dataset_geomean | ALL | eagle3 | common_decode_rate_ratio | 0.35572640496984426 | [0.35572640496984426, 0.35572640496984426] | 4 |
| four_dataset_geomean | ALL | dflash | common_decode_rate_ratio | 2.2328194441007145 | [2.2328194441007145, 2.2328194441007145] | 4 |
| four_dataset_geomean | ALL | domino | common_decode_rate_ratio | 120942.03586108041 | [120942.03586108041, 120942.03586108041] | 4 |
| four_dataset_geomean | ALL | dspark | common_decode_rate_ratio | 142828.35054202395 | [142828.35054202395, 142828.35054202395] | 4 |
| four_dataset_geomean | ALL | vanilla_fa | common_output_rate_ratio | 1.0 | [1.0, 1.0] | 4 |
| four_dataset_geomean | ALL | vanilla_hf | common_output_rate_ratio | 0.8739499254614683 | [0.8739499254614683, 0.8739499254614683] | 4 |
| four_dataset_geomean | ALL | eagle3 | common_output_rate_ratio | 0.5653735811810107 | [0.5653735811810107, 0.5653735811810107] | 4 |
| four_dataset_geomean | ALL | dflash | common_output_rate_ratio | 2.279535423009335 | [2.279535423009335, 2.279535423009335] | 4 |
| four_dataset_geomean | ALL | domino | common_output_rate_ratio | 8.776508015607593 | [8.776508015607593, 8.776508015607593] | 4 |
| four_dataset_geomean | ALL | dspark | common_output_rate_ratio | 8.992335639975169 | [8.992335639975169, 8.992335639975169] | 4 |

Decode ratios are emitted only for matching, verified first-token-to-final-token boundaries. `common_output_rate_ratio` is end-to-end output rate, not decode speedup.
Paper gate: `smoke_pass`. See `audit_v2.json` for exclusions, shared sample IDs, coverage, and qualification reasons.
